import { AboutSection } from '../components/AboutSection';

export function AboutPage() {
  return (
    <div className="pt-20">
      <AboutSection />
    </div>
  );
}