import { FamilyTherapySection } from '../components/FamilyTherapySection';

export function TherapyFamilyPage() {
  return (
    <div className="pt-20">
      <FamilyTherapySection />
    </div>
  );
}