import { FeedbackSection } from '../components/FeedbackSection';

export function TherapyFeedbackPage() {
  return (
    <div className="pt-20">
      <FeedbackSection />
    </div>
  );
}