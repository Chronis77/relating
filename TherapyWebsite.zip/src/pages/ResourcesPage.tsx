import { ResourcesSection } from '../components/ResourcesSection';

export function ResourcesPage() {
  return (
    <div className="pt-20">
      <ResourcesSection />
    </div>
  );
}