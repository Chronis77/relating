import { Card, CardContent } from '../components/ui/card';
import { Badge } from '../components/ui/badge';
import { Video } from 'lucide-react';

const videos = [
  {
    title: "Thich Nhat Hanh's – 4 wonderful mantras for couples",
    description: "This wonderful clip sums up EFT in 3 minutes. Although Thich Nhat Hanh is not purposefully referring to Emotionally Focused Couple Therapy (EFT), he manages to capture it perfectly. Simple, deep and wonderful!",
    duration: "3 minutes"
  },
  {
    title: "Sue Johnson – What is a healthy marriage?",
    description: "Relationship expert Dr. Sue Johnson addresses what constitutes a healthy marriage.",
    duration: "3.51 minutes"
  },
  {
    title: "John Gottman – Making relationships work (Part 1)",
    description: "Dr. John Gottman looks at relationships and the habits that are helpful versus the habits that are not helpful. Speaks of the Four Horsemen of the Apocalypse: Criticism, Contempt, Defensiveness, & Stonewalling.",
    duration: "10.10 minutes"
  }
];

export function ResourcesVideosPage() {
  return (
    <div className="pt-20">
      <section className="py-16 bg-gradient-to-b from-background to-muted/30">
        <div className="container mx-auto px-4 max-w-[1200px]">
          <div className="text-center mb-12 animate-fade-up">
            <h1 className="text-4xl md:text-5xl font-bold text-primary mb-4">Inspiring Videos</h1>
            <p className="text-lg text-muted-foreground">
              Educational and inspiring video content from relationship experts
            </p>
          </div>
          
          <div className="grid md:grid-cols-2 gap-6 animate-fade-up" style={{ animationDelay: '0.2s' }}>
            {videos.map((video, index) => (
              <Card key={index} className="glass-effect border-purple-100 shadow-lg hover:shadow-xl transition-all duration-300 hover:scale-105">
                <CardContent className="p-6">
                  <div className="flex items-center space-x-3 mb-4">
                    <Video className="h-6 w-6 text-primary" />
                    <Badge variant="secondary">{video.duration}</Badge>
                  </div>
                  <h3 className="font-semibold text-foreground mb-3">{video.title}</h3>
                  <p className="text-sm text-muted-foreground">{video.description}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
}