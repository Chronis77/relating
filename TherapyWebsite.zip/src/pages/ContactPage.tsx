import { ContactSection } from '../components/ContactSection';

export function ContactPage() {
  return (
    <div className="pt-20">
      <ContactSection />
    </div>
  );
}