import { TherapySection } from '../components/TherapySection';
import { FeedbackSection } from '../components/FeedbackSection';
import { FamilyTherapySection } from '../components/FamilyTherapySection';

export function TherapyPage() {
  return (
    <div className="pt-20">
      <TherapySection />
      <FeedbackSection />
      <FamilyTherapySection />
    </div>
  );
}