import { GeneralSection } from '../components/GeneralSection';

export function GeneralPage() {
  return (
    <div>
      <GeneralSection />
    </div>
  );
}